import 'package:flutter/material.dart';

const _bg = Color(0xFFF7F8FF);
const _dark = Color(0xFF1B5E20);
const _green = Color(0xFF2E7D32);
const _mintSoft = Color(0xFFCFF5CF);
const _ink = Color(0xFF1A1C24);
const _muted = Color(0xFF5F6670);

class CourierView extends StatelessWidget {
  const CourierView({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> tasks = [
      {
        'id': '#REG-20240527-01',
        'nama': 'Budi Santoso',
        'alamat': 'Jl. Revolusi No. 42, Kalumata',
        'kategori': 'Plastik & Kertas',
        'berat': '15 kg',
        'status': 'Menunggu',
        'waktu': 'Hari ini, 10:00 WIT',
      },
      {
        'id': '#REG-20240527-02',
        'nama': 'Siti Aminah',
        'alamat': 'Kel. Akehuda, Ternate Utara',
        'kategori': 'Minyak Jelantah',
        'berat': '5 Liter',
        'status': 'Menunggu',
        'waktu': 'Hari ini, 13:00 WIT',
      },
    ];

    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        title: const Text('Dashboard Kurir'),
        backgroundColor: _green,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(icon: const Icon(Icons.notifications_none), onPressed: () {}),
          const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.person, color: _green)),
          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_green, _dark], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildStat('3', 'Tugas Baru'),
                  Container(width: 1, height: 40, color: Colors.white30),
                  _buildStat('1', 'Sedang Jalan'),
                  Container(width: 1, height: 40, color: Colors.white30),
                  _buildStat('12', 'Selesai'),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text('Daftar Penjemputan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: _ink)),
            const SizedBox(height: 12),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: tasks.length,
              itemBuilder: (context, index) {
                final task = tasks[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: const [BoxShadow(color: Color(0x0F1A1C24), blurRadius: 10, offset: Offset(0, 4))],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(task['id'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(color: _mintSoft, borderRadius: BorderRadius.circular(8)),
                              child: Text(task['status'], style: const TextStyle(color: _dark, fontSize: 10, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(task['nama'], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.location_on_outlined, size: 16, color: _muted),
                            const SizedBox(width: 4),
                            Expanded(child: Text(task['alamat'], style: const TextStyle(fontSize: 13, color: _muted))),
                          ],
                        ),
                        const Divider(height: 24),
                        Row(
                          children: [
                            _buildInfoChip(Icons.recycling, task['kategori']),
                            const SizedBox(width: 8),
                            _buildInfoChip(Icons.scale, task['berat']),
                            const Spacer(),
                            Text(task['waktu'], style: const TextStyle(fontSize: 11, color: _muted)),
                          ],
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tugas ${task['id']} diambil!')));
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _green,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                            child: const Text('Ambil Tugas & Jalan'),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
      ],
    );
  }

  Widget _buildInfoChip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(8)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: _muted),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontSize: 11, color: _ink, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}